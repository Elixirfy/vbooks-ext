var API_URL = "https://truyencv.io/wp-json/initmanga/v1/chapter/";
var USER_AGENT = "Dart/3.11 (dart:io)";

function requestJson(url) {
    var body = Http.get(url).headers({
        "User-Agent": USER_AGENT,
        "Accept": "application/json"
    }).string();
    return JSON.parse(body);
}

function getId(url) {
    var match = String(url).match(/(\d+)\/?(?:[?#].*)?$/);
    return match ? match[1] : "";
}

function execute(url) {
    var id = getId(url);
    if (!id) return Response.error("Không tìm thấy ID chương.");
    var json = requestJson(API_URL + id);
    return Response.success(json.content || "");
}
