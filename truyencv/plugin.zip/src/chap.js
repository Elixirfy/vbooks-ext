var API_URL = "https://truyencv.io/wp-json/initmanga/v1/chapter/";
var USER_AGENT = "Dart/3.11 (dart:io)";

function requestJson(url) {
    var body = Http.get(url).headers({
        "User-Agent": USER_AGENT,
        "Accept": "application/json"
    }).string();
    return JSON.parse(body);
}

function execute(url) {
    var json = requestJson(API_URL + url);
    return Response.success(json.content || "");
}
