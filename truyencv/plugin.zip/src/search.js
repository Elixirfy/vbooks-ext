var API_URL = "https://truyencv.io/wp-json/wp/v2/manga";
var USER_AGENT = "Dart/3.11 (dart:io)";

function requestJson(url) {
    var body = Http.get(url).headers({
        "User-Agent": USER_AGENT,
        "Accept": "application/json"
    }).string();
    return JSON.parse(body);
}

function execute(query, page) {
    query = query || "";
    page = page || "1";
    var apiUrl = API_URL + "?search=" + encodeURIComponent(query);
    apiUrl += "&page=" + page + "&per_page=20&orderby=modified&order=desc&_embed=wp:featuredmedia,author";
    var items = requestJson(apiUrl);
    var list = [];

    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var embedded = item._embedded || {};
        var media = embedded["wp:featuredmedia"] || [];
        var authors = embedded.author || [];
        list.push({
            name: item.title && item.title.rendered ? item.title.rendered : "",
            link: item.id.toString(),
            cover: media.length > 0 ? media[0].source_url : "",
            description: authors.length > 0 ? authors[0].name : "",
            host: "https://truyencv.io"
        });
    }

    return Response.success(list, items.length > 0 ? (parseInt(page, 10) + 1).toString() : null);
}
