var API_URL = "https://truyencv.io/wp-json/initmanga/v1/chapters";
var USER_AGENT = "Dart/3.11 (dart:io)";

function requestJson(url) {
    var body = Http.get(url).headers({
        "User-Agent": USER_AGENT,
        "Accept": "application/json"
    }).string();
    return JSON.parse(body);
}

function execute(url) {
    var page = 1;
    var first = requestJson(API_URL + "?manga_id=" + url + "&paged=1&per_page=100");
    var totalPages = parseInt(first.total_pages, 10) || 1;
    var chapters = first.items || [];

    for (page = 2; page <= totalPages; page++) {
        var next = requestJson(API_URL + "?manga_id=" + url + "&paged=" + page + "&per_page=100");
        chapters = chapters.concat(next.items || []);
    }

    var list = [];
    for (var i = 0; i < chapters.length; i++) {
        var item = chapters[i];
        list.push({
            name: item.title || "Chương " + item.number,
            url: item.id.toString(),
            host: "https://truyencv.io"
        });
    }

    list.reverse();
    return Response.success(list);
}
