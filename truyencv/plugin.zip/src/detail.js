var API_URL = "https://truyencv.io/wp-json/wp/v2/manga/";
var USER_AGENT = "Dart/3.11 (dart:io)";

function requestJson(url) {
    var body = Http.get(url).headers({
        "User-Agent": USER_AGENT,
        "Accept": "application/json"
    }).string();
    return JSON.parse(body);
}

function execute(url) {
    var json = requestJson(API_URL + url + "?_embed=wp:featuredmedia,author,wp:term");
    var embedded = json._embedded || {};
    var media = embedded["wp:featuredmedia"] || [];
    var authors = embedded.author || [];
    var terms = embedded["wp:term"] || [];
    var genres = [];

    for (var i = 0; i < terms.length; i++) {
        var group = terms[i] || [];
        for (var j = 0; j < group.length; j++) {
            if (group[j].taxonomy === "genre") genres.push(group[j].name);
        }
    }

    return Response.success({
        name: json.title && json.title.rendered ? json.title.rendered : "",
        cover: media.length > 0 ? media[0].source_url : "",
        author: authors.length > 0 ? authors[0].name : "",
        description: json.content && json.content.rendered ? json.content.rendered : "",
        detail: genres.join(", "),
        host: "https://truyencv.io"
    });
}
