var cachedDoc = null;
var currentBaseUrl = "";

function execute(url) {
    var parts = url.split("#");
    var baseUrl = parts[0].split("?")[0];
    var chapId = parts.length > 1 ? parts[1] : "chuong-1";
    
    if (cachedDoc === null || currentBaseUrl !== baseUrl) {
        cachedDoc = Http.get(baseUrl).html();
        currentBaseUrl = baseUrl;
    }
    
    var contentEl = cachedDoc.select("article#" + chapId);
    
    if (contentEl.isEmpty()) {
         return Response.error("Không tìm thấy nội dung chương.");
    }
    
    return Response.success(contentEl.html());
}