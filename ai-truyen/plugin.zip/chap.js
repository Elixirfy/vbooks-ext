function execute(url) {
    var parts = url.split("#");
    var baseUrl = parts[0].split("?")[0];
    var chapId = parts.length > 1 ? parts[1] : "chuong-1";

    if (!/^chuong-\d+$/.test(chapId)) {
        return Response.error("Liên kết chương không hợp lệ.");
    }

    var doc = Http.get(baseUrl + "#" + chapId).html();
    var content = doc.select("#readerContent");
    if (content.isEmpty() || !content.text().trim()) {
        return Response.error("Không tìm thấy nội dung chương trong trang HTML.");
    }
    return Response.success(content.html());
}