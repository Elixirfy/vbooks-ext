function execute(url) {
    url = url.split("?")[0].split("#")[0];
    var doc = Http.get(url).html();
    var list = [];
    var els = doc.select("#tocList .toc-item");

    for (var i = 0; i < els.size(); i++) {
        var el = els.get(i);
        var chapNumber = el.select(".toc-item-number").text();
        var chapTitle = el.select(".toc-item-title").text();
        var numMatch = chapNumber.match(/\d+/);

        if (numMatch) {
            list.push({
                name: chapNumber + (chapTitle ? ": " + chapTitle : ""),
                url: url + "#chuong-" + numMatch[0],
                host: "https://static.aitruyen.net"
            });
        }
    }

    if (list.length === 0) {
        return Response.error("Không tìm thấy mục lục chương trong trang HTML.");
    }
    return Response.success(list);
}