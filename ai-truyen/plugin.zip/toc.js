function execute(url) {
    url = url.split("?")[0].split("#")[0];
    var doc = Http.get(url).html();
    var list = [];
    
    var els = doc.select("#tocList .toc-item");
    for (var i = 0; i < els.size(); i++) {
        var el = els.get(i);
        var chapNumber = el.select(".toc-item-number").text();
        var chapTitle = el.select(".toc-item-title").text();
        
        var numMatch = chapNumber.match(/\d+/);
        if (numMatch) {
            var id = "chuong-" + numMatch[0];
            list.push({
                name: chapNumber + ": " + chapTitle,
                url: url + "#" + id,
                host: "https://static.aitruyen.net"
            });
        }
    }
    return Response.success(list);
}