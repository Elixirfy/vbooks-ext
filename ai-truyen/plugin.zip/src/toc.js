function execute(url) {
    url = url.split("?")[0].split("#")[0];
    var textUrl = url.replace(/\.html?$/i, ".txt");
    var text = Http.get(textUrl).string();
    var list = [];
    var pattern = /^Chương\s+(\d+)\s*:\s*(.+)$/gim;
    var matches = [];
    var match;

    while ((match = pattern.exec(text)) !== null) {
        matches.push({
            number: match[1],
            title: match[2].trim(),
            start: match.index
        });
    }

    for (var i = 0; i < matches.length; i++) {
        var chapter = matches[i];
        var end = i + 1 < matches.length ? matches[i + 1].start : text.length;
        list.push({
            name: "Chương " + chapter.number + ": " + chapter.title,
            url: textUrl + "?start=" + chapter.start + "&end=" + end,
            host: "https://static.aitruyen.net"
        });
    }

    if (list.length === 0) return Response.error("Không tìm thấy mục lục chương.");
    return Response.success(list);
}