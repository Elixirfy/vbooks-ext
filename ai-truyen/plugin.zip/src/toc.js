function execute(url) {
    // Giữ lại link gốc (.html) để dùng cho việc tạo URL của từng chương
    var baseUrl = url.split("?")[0].split("#")[0]; 
    
    // Chuyển thành .txt chỉ để tải danh sách
    var textUrl = baseUrl.replace("truyen-", "").replace(/\.html?$/i, ".txt");
    var text = Http.get(textUrl).string();
    var list = [];
    var pattern = /^Chương\s+(\d+)\s*:\s*(.+)$/gim;
    var matches = [];
    var match;

    while ((match = pattern.exec(text)) !== null) {
        matches.push({
            number: match[1],
            title: match[2].trim(),
            start: match.index
        });
    }

    for (var i = 0; i < matches.length; i++) {
        var chapter = matches[i];
        var end = i + 1 < matches.length ? matches[i + 1].start : text.length;
        list.push({
            name: "Chương " + chapter.number + ": " + chapter.title,
            // Đưa baseUrl (.html) vào để VBook nhận diện được extension
            url: baseUrl + "?start=" + chapter.start + "&end=" + end,
            host: "https://static.aitruyen.net"
        });
    }

    if (list.length === 0) return Response.error("Không tìm thấy mục lục chương.");
    return Response.success(list);
}