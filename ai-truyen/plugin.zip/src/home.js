function execute() {
    return Response.success([
        {title: "Truyện của tôi", input: "https://static.aitruyen.net/truyen-no-le-bong-toi.html", script: "gen.js"}
    ]);
}