var cachedText = null;
var cachedUrl = "";

function getParameter(url, name) {
    var match = url.match(new RegExp("[?&]" + name + "=(\\d+)"));
    return match ? parseInt(match[1], 10) : -1;
}

function execute(url) {
    // url lúc này đang là .../truyen-no-le-bong-toi.html?start=123&end=456
    var baseUrl = url.split("?")[0];
    
    // Chuyển lại thành .txt để kết nối tới file dữ liệu 8.4MB
    var textUrl = baseUrl.replace("truyen-", "").replace(/\.html?$/i, ".txt");
    var start = getParameter(url, "start");
    var end = getParameter(url, "end");

    if (start < 0 || end <= start) {
        return Response.error("Thiếu tọa độ chương.");
    }

    if (cachedText === null || cachedUrl !== textUrl) {
        cachedText = Http.get(textUrl).string();
        cachedUrl = textUrl;
    }

    if (end > cachedText.length) end = cachedText.length;
    var content = cachedText.substring(start, end).replace(/\r?\n/g, "<br>");
    
    return Response.success(content);
}