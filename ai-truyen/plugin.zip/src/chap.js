var cachedText = null;

function getParameter(url, name) {
    var match = url.match(new RegExp("[?&]" + name + "=(\\d+)"));
    return match ? parseInt(match[1], 10) : -1;
}

function execute(url) {
    var start = getParameter(url, "start");
    var end = getParameter(url, "end");

    if (start < 0 || end <= start) {
        return Response.error("Thiếu tọa độ chương.");
    }

    // Load thẳng file txt, bỏ qua bước bóc tách từ url
    if (cachedText === null) {
        cachedText = Http.get("https://static.aitruyen.net/no-le-bong-toi.txt").string();
    }

    if (!cachedText) {
        return Response.error("Không thể tải nội dung truyện");
    }

    if (end > cachedText.length) end = cachedText.length;
    
    var content = cachedText.substring(start, end).replace(/\r?\n/g, "<br>");
    
    return Response.success(content);
}