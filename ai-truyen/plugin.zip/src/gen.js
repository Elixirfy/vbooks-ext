function execute(url, page) {
    var list = [{
        name: "Nô Lệ Bóng Tối",
        link: "https://static.aitruyen.net/truyen-no-le-bong-toi.html",
        cover: "icon.png",
        description: "Shadow Slave VN",
        host: "https://static.aitruyen.net"
    }];
    return Response.success(list);
}
