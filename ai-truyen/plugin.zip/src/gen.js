function execute(url, page) {
    var list = [{
        name: "Nô Lệ Bóng Tối",
        link: "https://static.aitruyen.net/truyen-no-le-bong-toi.html",
        cover: "https://covers.lnaudio.app/shadow_slave/cover.webp",
        description: "Shadow Slave VN",
        host: "https://static.aitruyen.net"
    }];
    return Response.success(list);
}
