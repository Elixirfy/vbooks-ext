var cachedText = null;

function escapeHtml(text) {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function parseChapters(text) {
    var chapters = [];
    var chapterPattern = /^Chương\s+(\d+)\s*:\s*(.+)$/gim;
    var matches = [];
    var match;

    while ((match = chapterPattern.exec(text)) !== null) {
        matches.push({ number: match[1], title: match[2].trim(), start: match.index });
    }

    for (var i = 0; i < matches.length; i++) {
        var current = matches[i];
        var end = i + 1 < matches.length ? matches[i + 1].start : text.length;
        chapters.push({
            number: current.number,
            title: current.title,
            content: text.substring(current.start, end).replace(/^[^\n]*\n/, "").trim()
        });
    }
    return chapters;
}

function execute(url) {
    var parts = url.split("#");
    var chapId = parts.length > 1 ? parts[1] : "chuong-1";
    var numberMatch = chapId.match(/^chuong-(\d+)$/i);

    if (!numberMatch) {
        return Response.error("Liên kết chương không hợp lệ.");
    }
    
    if (cachedText === null) {
        cachedText = Http.get("https://static.aitruyen.net/no-le-bong-toi.txt").string();
    }
    
    var chapters = parseChapters(cachedText);
    var chapter = null;
    for (var i = 0; i < chapters.length; i++) {
        if (chapters[i].number === numberMatch[1]) {
            chapter = chapters[i];
            break;
        }
    }

    if (chapter === null) {
         return Response.error("Không tìm thấy nội dung chương.");
    }

    var paragraphs = escapeHtml(chapter.content).split(/\n\s*\n/);
    var html = "<h2>Chương " + chapter.number + ": " + escapeHtml(chapter.title) + "</h2>";
    for (var p = 0; p < paragraphs.length; p++) {
        if (paragraphs[p].trim()) html += "<p>" + paragraphs[p].replace(/\n/g, "<br>") + "</p>";
    }
    return Response.success(html);
}