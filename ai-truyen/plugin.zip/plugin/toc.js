var dataUrl = "https://static.aitruyen.net/no-le-bong-toi.txt";

function parseChapters(text) {
    var list = [];
    var chapterPattern = /^Chương\s+(\d+)\s*:\s*(.+)$/gim;
    var matches = [];
    var match;

    while ((match = chapterPattern.exec(text)) !== null) {
        matches.push({
            number: match[1],
            title: match[2].trim(),
            start: match.index
        });
    }

    for (var i = 0; i < matches.length; i++) {
        var chapter = matches[i];
        list.push({
            name: "Chương " + chapter.number + ": " + chapter.title,
            url: "https://static.aitruyen.net/truyen-no-le-bong-toi.html#chuong-" + chapter.number,
            host: "https://static.aitruyen.net"
        });
    }
    return list;
}

function execute(url) {
    return Response.success(parseChapters(Http.get(dataUrl).string()));
}