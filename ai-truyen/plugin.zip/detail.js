function execute(url) {
    url = url.split("?")[0]; 
    var doc = Http.get(url).html();
    
    var name = doc.select("h1.brand-title").text();
    if (!name) name = doc.select("title").text().replace(" - AI Truyện", "");
    
    var author = doc.select("p.brand-subtitle").text(); 
    var chapterCount = doc.select("#chapterCount").text();
    
    return Response.success({
        name: name,
        cover: "https://static.aitruyen.net/favicon.ico",
        author: author,
        description: "Truyện: " + name + "<br>" + chapterCount,
        detail: "Tình trạng: " + chapterCount,
        host: "https://static.aitruyen.net"
    });
}